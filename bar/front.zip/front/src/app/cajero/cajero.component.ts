import { Component } from '@angular/core';

@Component({
  selector: 'app-cajero',
  templateUrl: './cajero.component.html',
  styleUrl: './cajero.component.css'
})
export class CajeroComponent {

}
