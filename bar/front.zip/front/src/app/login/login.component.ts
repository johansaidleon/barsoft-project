import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  username: string = '';
  password: string = '';
  message: string = '';

  constructor(private authService: AuthService, private router: Router) { }

  onLogin() {
    this.authService.login(this.username, this.password).subscribe(
      response => {
        this.message = response.message;
        const role = response.role;

        // Redirigir según el rol del usuario
        if (role === 'administrador') {
          this.router.navigate(['/admin']);
        } else if (role === 'mesero') {
          this.router.navigate(['/mesero']);
        } else if (role === 'cajero') {
          this.router.navigate(['/cajero']);
        }
      },
      error => {
        this.message = error.error.message;
      }
    );
  }
}
