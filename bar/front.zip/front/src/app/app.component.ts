import { Component, OnInit } from '@angular/core';
import { DataService } from './services/data.service'; // Importa el servicio

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'], // Corrige el nombre de la propiedad styleUrls
})
export class AppComponent implements OnInit {
  title = 'barsoft';
  data: any;

  constructor(private dataService: DataService) {} // Inyecta el servicio

  ngOnInit(): void {
    this.dataService.getData().subscribe(
      (response) => {
        this.data = response; // Almacena la respuesta del backend
        console.log(this.data); // Imprime los datos en la consola
      },
      (error) => {
        console.error('Error al obtener datos', error); // Manejo de errores
      }
    );
  }
}
