import { Component } from '@angular/core';

@Component({
  selector: 'app-mesero',
  templateUrl: './mesero.component.html',
  styleUrl: './mesero.component.css'
})
export class MeseroComponent {

}
