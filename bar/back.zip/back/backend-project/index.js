const express = require('express');
const cors = require('cors');
const authRoutes = require('./authRoutes'); // Importa las rutas de autenticación

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

// Ruta principal
app.get('/', (req, res) => {
    res.send('Backend con Express y JavaScript está funcionando');
});

// Usa las rutas de autenticación bajo el prefijo /api
app.use('/api', authRoutes);

// Manejo de errores
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).send('Algo salió mal!');
});

// Inicia el servidor
app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
