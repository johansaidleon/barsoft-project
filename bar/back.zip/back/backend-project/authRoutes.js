const express = require('express');
const router = express.Router();

// Lista de usuarios de prueba (credenciales quemadas)
const users = [
    {
        username: 'admin',
        password: '@dmin1712',
        role: 'administrador'
    },
    {
        username: 'mesero1',
        password: 'M3sero1712',
        role: 'mesero'
    },
    {
        username: 'cajero1',
        password: 'c@jero1712',
        role: 'cajero'
    }
];

// Ruta para autenticación de usuarios
router.post('/login', (req, res) => {
    const { username, password } = req.body;
    const user = users.find(u => u.username === username && u.password === password);

    if (user) {
        res.json({ message: 'Login exitoso', role: user.role });
    } else {
        res.status(401).json({ message: 'Credenciales incorrectas' });
    }
});

// Ruta para obtener datos de prueba
router.get('/data', (req, res) => {
    res.json({ message: 'Datos desde el backend con Node.js' });
});

module.exports = router;
